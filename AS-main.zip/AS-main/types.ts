export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  status: 'online' | 'offline' | 'busy';
  coverPhoto?: string;
  bio?: string;
}

export interface Reaction {
  emoji: string;
  userId: string;
}

export interface Message {
  id: string;
  senderId: string;
  content: string;
  type: 'text' | 'image' | 'audio' | 'file';
  timestamp: number;
  read: boolean;
  imageUrl?: string;
  audioUrl?: string;
  duration?: number;
  fileName?: string;
  fileSize?: string;
  reactions?: Reaction[];
}

export interface Chat {
  id: string;
  participants: User[];
  messages: Message[];
  unreadCount: number;
  pinned: boolean;
  isGroup: boolean;
  groupName?: string;
  theme?: string; // Background image URL
}

export interface CallLog {
  id: string;
  userId: string;
  type: 'audio' | 'video';
  direction: 'incoming' | 'outgoing';
  timestamp: number;
  duration: string;
}

export type ViewState = 'auth' | 'chats' | 'chat_room' | 'profile' | 'calls' | 'contacts' | 'privacy_settings' | 'add_friend' | 'invite_friends' | 'permissions' | 'ad_settings' | 'blocked_contacts' | 'scan_code';