import { User, Chat, Message, CallLog } from '../types';

const USERS_STORAGE_KEY = 'as_chat_users_db';

// Helper to get users from storage or initialize default
const getUsersFromStorage = (): any[] => {
    try {
        const stored = localStorage.getItem(USERS_STORAGE_KEY);
        if (stored) return JSON.parse(stored);
    } catch (e) {
        console.error("Error loading users", e);
    }
    
    // Default initial user if storage is empty
    const defaults = [
        { 
            id: '1', 
            email: 'alice@test.com', 
            password: 'password', 
            name: 'Alice Johnson', 
            avatar: 'https://picsum.photos/200?random=1', 
            status: 'online', 
            dob: '1990-01-01',
            bio: 'Lover of nature and tech! 🌿💻'
        }
    ];
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(defaults));
    return defaults;
}

// Mock Data for Chats (visuals only)
const MOCK_CHATS: Chat[] = [
  {
    id: 'c1',
    participants: [{ id: '1', name: 'Alice Johnson', email: 'alice@test.com', avatar: 'https://picsum.photos/200?random=1', status: 'online', bio: 'Lover of nature and tech! 🌿💻' }],
    unreadCount: 2,
    pinned: true,
    isGroup: false,
    messages: [
      { id: 'm1', senderId: '1', content: 'Hey! How are you?', type: 'text', timestamp: Date.now() - 100000, read: true },
      { id: 'm2', senderId: 'me', content: 'I am doing great, thanks!', type: 'text', timestamp: Date.now() - 50000, read: true },
      { id: 'm3', senderId: '1', content: 'Video call later?', type: 'text', timestamp: Date.now(), read: false },
    ]
  },
  {
    id: 'c2',
    participants: [{ id: '2', name: 'Bob Smith', email: 'bob@test.com', avatar: 'https://picsum.photos/200?random=2', status: 'offline', bio: 'Busy building things.' }],
    unreadCount: 0,
    pinned: false,
    isGroup: false,
    messages: [
      { id: 'm4', senderId: 'me', content: 'Did you see the file?', type: 'text', timestamp: Date.now() - 86400000, read: true },
    ]
  }
];

const MOCK_CALLS: CallLog[] = [
  { id: 'cl1', userId: '1', type: 'video', direction: 'incoming', timestamp: Date.now() - 3600000, duration: '5:23' },
  { id: 'cl2', userId: '2', type: 'audio', direction: 'outgoing', timestamp: Date.now() - 86400000, duration: '12:04' },
];

export const mockService = {
  login: async (email: string, password: string): Promise<User> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const currentUsers = getUsersFromStorage();
        const user = currentUsers.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
        
        if (!user) {
          reject(new Error("Account not found. Please Sign Up first."));
          return;
        }

        if (user.password !== password) {
          reject(new Error("Incorrect password."));
          return;
        }

        resolve({ 
            id: user.id, 
            name: user.name, 
            email: user.email, 
            avatar: user.avatar, 
            status: 'online',
            coverPhoto: user.coverPhoto || 'https://picsum.photos/800/350?random=10',
            bio: user.bio || 'Hey there! I am using AS Chat.'
        });
      }, 1000);
    });
  },

  checkEmailExists: async (email: string): Promise<boolean> => {
      return new Promise((resolve) => {
          setTimeout(() => {
              const currentUsers = getUsersFromStorage();
              const exists = currentUsers.some((u: any) => u.email.toLowerCase() === email.toLowerCase());
              resolve(exists);
          }, 500);
      });
  },

  signUp: async (data: any): Promise<User> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const currentUsers = getUsersFromStorage();
        
        // 1. Check if email exists (double check)
        const exists = currentUsers.find((u: any) => u.email.toLowerCase() === data.email.toLowerCase());
        if (exists) {
            reject(new Error("This Gmail is already registered. Please Sign In."));
            return;
        }

        // 2. Create new user
        const newUser = {
            id: `u_${Date.now()}`,
            email: data.email,
            password: data.password,
            name: `${data.firstName} ${data.lastName}`,
            dob: data.dob,
            avatar: `https://ui-avatars.com/api/?name=${data.firstName}+${data.lastName}&background=random`,
            status: 'online',
            bio: 'Hey there! I am using AS Chat.'
        };

        currentUsers.push(newUser);
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(currentUsers));

        resolve({
            id: newUser.id,
            name: newUser.name,
            email: newUser.email,
            avatar: newUser.avatar,
            status: 'online',
            coverPhoto: 'https://picsum.photos/800/350?random=20',
            bio: newUser.bio
        });
      }, 1500);
    });
  },

  searchUserByEmail: async (email: string): Promise<User | null> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const currentUsers = getUsersFromStorage();
        const user = currentUsers.find((u: any) => u.email.toLowerCase() === email.trim().toLowerCase());
        
        if (user) {
             resolve({ 
                id: user.id, 
                name: user.name, 
                email: user.email, 
                avatar: user.avatar, 
                status: user.status || 'online',
                coverPhoto: user.coverPhoto,
                bio: user.bio
            });
        } else {
            resolve(null);
        }
      }, 800);
    });
  },

  updateBio: async (userId: string, bio: string): Promise<void> => {
      const currentUsers = getUsersFromStorage();
      const index = currentUsers.findIndex((u: any) => u.id === userId);
      if (index !== -1) {
          currentUsers[index].bio = bio;
          localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(currentUsers));
      }
      return Promise.resolve();
  },

  getChats: async (): Promise<Chat[]> => {
    return Promise.resolve(MOCK_CHATS);
  },

  getHistory: async (): Promise<CallLog[]> => {
    return Promise.resolve(MOCK_CALLS);
  },

  getContacts: async (): Promise<User[]> => {
    // Return other registered users plus some mocks for population
    const currentUsers = getUsersFromStorage();
    const otherRegistered = currentUsers.map((u: any) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        avatar: u.avatar,
        status: u.status,
        bio: u.bio
    }));
    
    // Combine mock contacts
    const mockContacts = [
        { id: '2', name: 'Bob Smith', email: 'bob@test.com', avatar: 'https://picsum.photos/200?random=2', status: 'offline', bio: 'Busy building things.' },
        { id: '3', name: 'Charlie Davis', email: 'charlie@test.com', avatar: 'https://picsum.photos/200?random=3', status: 'busy', bio: 'At the gym 💪' },
    ];
    
    // Simple deduplication
    const allUsers = [...otherRegistered, ...mockContacts];
    const uniqueUsers = Array.from(new Map(allUsers.map(item => [item.id, item])).values());

    return Promise.resolve(uniqueUsers);
  }
};