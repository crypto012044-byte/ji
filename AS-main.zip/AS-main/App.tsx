import React, { useState, useEffect, useRef } from 'react';
import { User, Chat, ViewState, CallLog } from './types';
import { mockService } from './services/mockService';
import Auth from './components/Auth';
import ChatWindow from './components/ChatWindow';
import CallModal from './components/CallModal';
import AdBanner from './components/AdBanner';
import { 
  MessageSquare, 
  Phone, 
  Users, 
  Settings, 
  Plus, 
  Search, 
  Pin,
  Camera,
  LogOut,
  Edit2,
  Video,
  ArrowLeft,
  Shield,
  Eye,
  Lock,
  UserX,
  CheckCircle2,
  UserPlus,
  QrCode,
  Scan,
  Share2,
  Gift,
  Mail,
  Copy,
  Facebook,
  Twitter,
  MessageCircle,
  Mic,
  Image as ImageIcon,
  Megaphone,
  AlertCircle,
  X,
  Zap,
  ZapOff,
  MoreVertical,
  Unlock,
  Cpu,
  Loader2,
  Moon,
  Sun,
  PhoneIncoming
} from 'lucide-react';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [view, setView] = useState<ViewState>('auth');
  const [chats, setChats] = useState<Chat[]>([]);
  const [callHistory, setCallHistory] = useState<CallLog[]>([]);
  const [contacts, setContacts] = useState<User[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [activeCall, setActiveCall] = useState<{user: User, type: 'audio' | 'video', direction: 'incoming' | 'outgoing'} | null>(null);
  const [loading, setLoading] = useState(true);

  // Theme State - Forced to Dark Mode
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Add Friend State
  const [searchTerm, setSearchTerm] = useState('');
  const [addFriendSearchTriggered, setAddFriendSearchTriggered] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [foundUser, setFoundUser] = useState<User | null>(null);
  const [searchFeedback, setSearchFeedback] = useState('');

  // Search States for Lists
  const [chatSearchText, setChatSearchText] = useState('');
  const [chatFilter, setChatFilter] = useState('');
  const [contactSearchText, setContactSearchText] = useState('');

  // Chat List Menu State
  const [chatListMenuId, setChatListMenuId] = useState<string | null>(null);

  // Scan Code State
  const [flashlightOn, setFlashlightOn] = useState(false);
  const [scanResult, setScanResult] = useState<User | null>(null);

  // QR Code Modal
  const [showQrModal, setShowQrModal] = useState(false);
  const [isAiGeneratingQr, setIsAiGeneratingQr] = useState(false);

  // Bio Editing State
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [bioInput, setBioInput] = useState('');

  // Blocked Users State
  const [blockedUsers, setBlockedUsers] = useState<User[]>([
    { id: 'b1', name: 'Spam Bot', email: 'spam@bot.com', avatar: 'https://picsum.photos/200?random=101', status: 'offline', bio: '' },
    { id: 'b2', name: 'Unknown Caller', email: 'unknown@test.com', avatar: 'https://picsum.photos/200?random=102', status: 'offline', bio: '' }
  ]);

  // Privacy State
  const [privacySettings, setPrivacySettings] = useState({
    lastSeen: 'Everyone',
    profilePhoto: 'My Contacts',
    readReceipts: true,
  });

  // App Permissions State
  const [appPermissions, setAppPermissions] = useState({
    camera: true,
    microphone: true,
    gallery: true
  });

  // App Lock State
  const [securityPin, setSecurityPin] = useState<string | null>(null); // The set PIN
  const [isLocked, setIsLocked] = useState(false); // Is app currently locked?
  const [lockInput, setLockInput] = useState(''); // Current input in lock screen
  const [isSettingPin, setIsSettingPin] = useState(false); // Mode to set pin

  // Ad Settings State
  const [showAds, setShowAds] = useState(true);

  // Invite Yarn State
  const [invitePulled, setInvitePulled] = useState(false);

  const profileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  // Apply Theme Effect - FORCE DARK MODE
  useEffect(() => {
    document.documentElement.classList.add('dark');
    localStorage.setItem('as_chat_theme', 'dark');
  }, []);

  // Check for persistent session on mount
  useEffect(() => {
      const savedSession = localStorage.getItem('as_chat_session');
      if (savedSession) {
          try {
              const user = JSON.parse(savedSession);
              setCurrentUser(user);
              setView('chats');
          } catch (e) {
              console.error("Failed to restore session", e);
          }
      }
  }, []);

  // Initialize Data
  useEffect(() => {
    if (currentUser) {
      setLoading(true);
      Promise.all([
        mockService.getChats(), 
        mockService.getHistory(),
        mockService.getContacts()
      ])
        .then(([c, h, u]) => {
          setChats(c);
          setCallHistory(h);
          setContacts(u.filter(user => user.id !== currentUser.id));
          setLoading(false);
        });
    }
  }, [currentUser]);

  // Handle Lock Input
  useEffect(() => {
    if (lockInput.length === 4) {
      if (isSettingPin) {
        setSecurityPin(lockInput);
        setIsSettingPin(false);
        setLockInput('');
        alert('App Lock Enabled! Defaulting to locked state for security.');
        setIsLocked(true);
      } else if (isLocked || securityPin) {
         // Verify PIN
         if (lockInput === securityPin) {
             setIsLocked(false);
             setLockInput('');
         } else {
             setLockInput('');
             // Vibrate for error
             if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(200);
             alert('Incorrect PIN');
         }
      }
    }
  }, [lockInput, isSettingPin, securityPin, isLocked]);

  // Handle Scanner Simulation
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (view === 'scan_code') {
        setScanResult(null);
        // Simulate finding a user after 3 seconds
        timer = setTimeout(() => {
            const mockUser: User = { 
                id: 'scanned_user', 
                name: 'Sarah Connor', 
                email: 'sarah@test.com', 
                avatar: 'https://picsum.photos/200?random=99', 
                status: 'online', 
                bio: 'No fate but what we make.' 
            };
            setScanResult(mockUser);
            if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(100);
        }, 3000);
    }
    return () => clearTimeout(timer);
  }, [view]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setView('chats');
    // Save session
    localStorage.setItem('as_chat_session', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setView('auth');
    setActiveChatId(null);
    setSecurityPin(null);
    setIsLocked(false);
    // Clear session
    localStorage.removeItem('as_chat_session');
  };

  const startCall = (user: User, type: 'audio' | 'video') => {
    setActiveCall({ user, type, direction: 'outgoing' });
  };
  
  const simulateIncomingCall = () => {
      // Find a contact to call us or fake one
      const caller = contacts.length > 0 ? contacts[0] : { 
          id: 'sim_caller', 
          name: 'Jennifer Lawrence', 
          email: 'jen@test.com', 
          avatar: 'https://picsum.photos/200?random=500', 
          status: 'online' 
      } as User;
      
      setActiveCall({
          user: caller,
          type: Math.random() > 0.5 ? 'video' : 'audio',
          direction: 'incoming'
      });
  };

  const handleStartChat = (contact: User) => {
    // Check if chat exists
    let chat = chats.find(c => c.participants.some(p => p.id === contact.id) && !c.isGroup);
    
    if (!chat) {
      // Create new mock chat
      const newChat: Chat = {
        id: `new_${Date.now()}`,
        participants: [currentUser!, contact],
        messages: [],
        unreadCount: 0,
        pinned: false,
        isGroup: false,
        theme: undefined
      };
      setChats([newChat, ...chats]);
      chat = newChat;
    }
    
    setActiveChatId(chat.id);
    setView('chat_room');
  };

  const handleAddUser = (newUser: User) => {
    // Check if already in contacts
    if (!contacts.find(c => c.id === newUser.id)) {
        setContacts([...contacts, newUser]);
    }
    setView('contacts');
    setSearchTerm('');
    setAddFriendSearchTriggered(false);
  };

  const handleSearchUser = async () => {
    if (!searchTerm.trim()) return;
    setIsSearching(true);
    setFoundUser(null);
    setSearchFeedback('');
    setAddFriendSearchTriggered(false);

    try {
        const user = await mockService.searchUserByEmail(searchTerm);
        if (user) {
            if (user.id === currentUser?.id) {
                 setSearchFeedback("You cannot add yourself.");
                 setAddFriendSearchTriggered(true);
            } else {
                 setFoundUser(user);
                 setAddFriendSearchTriggered(true);
            }
        } else {
            setSearchFeedback("User not found.");
            setAddFriendSearchTriggered(true);
        }
    } catch (e) {
        setSearchFeedback("Error occurred.");
        setAddFriendSearchTriggered(true);
    } finally {
        setIsSearching(false);
    }
  };

  const handleUnblock = (userId: string) => {
    setBlockedUsers(blockedUsers.filter(u => u.id !== userId));
  };

  const handleBlockUser = (userToBlock: User) => {
      setBlockedUsers(prev => {
          if (prev.find(u => u.id === userToBlock.id)) return prev;
          return [...prev, userToBlock];
      });
      // Optionally return to chats view
      setView('chats');
      setActiveChatId(null);
  };

  const handleProfilePhotoUpdate = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && currentUser) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const updatedUser = { ...currentUser, avatar: reader.result as string };
        setCurrentUser(updatedUser);
        localStorage.setItem('as_chat_session', JSON.stringify(updatedUser));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCoverPhotoUpdate = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && currentUser) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const updatedUser = { ...currentUser, coverPhoto: reader.result as string };
        setCurrentUser(updatedUser);
        localStorage.setItem('as_chat_session', JSON.stringify(updatedUser));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveBio = () => {
    if(currentUser) {
        const updated = { ...currentUser, bio: bioInput };
        setCurrentUser(updated);
        setIsEditingBio(false);
        
        // Persist updates
        localStorage.setItem('as_chat_session', JSON.stringify(updated));
        mockService.updateBio(currentUser.id, bioInput);
    }
  };

  const handleYarnPull = () => {
    if (invitePulled) return;
    setInvitePulled(true);
    // Vibrate if available
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate([50, 50, 50]);
    }
    setTimeout(() => setInvitePulled(false), 2500);
  };

  const handleShare = async () => {
      const shareData = {
          title: 'AS Chat',
          text: 'Join me on AS - the secure chat app! Connect with video calls and more.',
          url: `https://as.app/u/${currentUser?.id}`,
      };

      try {
          if (navigator.share) {
              await navigator.share(shareData);
          } else {
              // Fallback
              navigator.clipboard.writeText(shareData.url);
              alert('Link copied to clipboard!');
          }
      } catch (err) {
          console.error('Error sharing:', err);
      }
  };

  const toggleAppLockSetup = () => {
      if (securityPin) {
          // If already set, remove it (in a real app, confirm old pin first)
          if(window.confirm("Disable App Lock?")) {
              setSecurityPin(null);
          }
      } else {
          setIsSettingPin(true);
      }
  }

  const handleOpenQrModal = () => {
      setShowQrModal(true);
      setIsAiGeneratingQr(true);
      // Simulate AI generation delay
      setTimeout(() => {
          setIsAiGeneratingQr(false);
      }, 2000);
  }

  if (!currentUser && view !== 'auth') {
    // Safety check: if view is not auth but no user, fallback to auth
     if (localStorage.getItem('as_chat_session')) return null; // loading...
     return <Auth onLogin={handleLogin} />;
  }
  
  if (!currentUser || view === 'auth') {
    return <Auth onLogin={handleLogin} />;
  }

  const activeChat = chats.find(c => c.id === activeChatId);

  // -- RENDER HELPERS --

  const renderBottomNav = () => (
    <div className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 flex justify-around items-center py-3 pb-safe z-30 transition-colors duration-300">
      <button onClick={() => setView('chats')} className={`flex flex-col items-center gap-1 ${view === 'chats' ? 'text-blue-600' : 'text-gray-400 dark:text-gray-500'}`}>
        <MessageSquare className="w-6 h-6" />
        <span className="text-[10px] font-medium">Chats</span>
      </button>
      <button onClick={() => setView('calls')} className={`flex flex-col items-center gap-1 ${view === 'calls' ? 'text-blue-600' : 'text-gray-400 dark:text-gray-500'}`}>
        <Phone className="w-6 h-6" />
        <span className="text-[10px] font-medium">Calls</span>
      </button>
      <button onClick={() => setView('contacts')} className={`flex flex-col items-center gap-1 ${view === 'contacts' ? 'text-blue-600' : 'text-gray-400 dark:text-gray-500'}`}>
        <Users className="w-6 h-6" />
        <span className="text-[10px] font-medium">People</span>
      </button>
      <button onClick={() => setView('profile')} className={`flex flex-col items-center gap-1 ${view === 'profile' ? 'text-blue-600' : 'text-gray-400 dark:text-gray-500'}`}>
        <div className="w-6 h-6 rounded-full overflow-hidden border border-current">
          <img src={currentUser.avatar} alt="Me" className="w-full h-full object-cover" />
        </div>
        <span className="text-[10px] font-medium">Profile</span>
      </button>
    </div>
  );

  const renderLockScreen = () => (
      <div className="absolute inset-0 z-[60] bg-blue-600 flex flex-col items-center justify-center text-white animate-fade-in">
          <div className="mb-8 flex flex-col items-center">
              <div className="bg-white/20 p-4 rounded-full mb-4">
                  <Lock className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-2xl font-bold">{isSettingPin ? 'Set New PIN' : 'App Locked'}</h2>
              <p className="text-blue-100">{isSettingPin ? 'Enter a 4-digit code' : 'Enter PIN to unlock'}</p>
          </div>

          <div className="flex gap-4 mb-8">
              {[0, 1, 2, 3].map(i => (
                  <div key={i} className={`w-4 h-4 rounded-full border-2 border-white ${lockInput.length > i ? 'bg-white' : 'bg-transparent'}`}></div>
              ))}
          </div>

          <div className="grid grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                  <button 
                    key={num}
                    onClick={() => setLockInput(prev => (prev.length < 4 ? prev + num : prev))}
                    className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-2xl font-bold transition active:scale-95"
                  >
                      {num}
                  </button>
              ))}
              <div className="w-16 h-16"></div>
              <button 
                 onClick={() => setLockInput(prev => (prev.length < 4 ? prev + '0' : prev))}
                 className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-2xl font-bold transition active:scale-95"
              >
                  0
              </button>
              <button 
                 onClick={() => setLockInput(prev => prev.slice(0, -1))}
                 className="w-16 h-16 rounded-full flex items-center justify-center text-white/70 hover:text-white transition active:scale-95"
              >
                  <ArrowLeft className="w-6 h-6" />
              </button>
          </div>
          {isSettingPin && (
              <button onClick={() => { setIsSettingPin(false); setLockInput(''); }} className="mt-8 text-sm opacity-80 hover:opacity-100">Cancel</button>
          )}
      </div>
  );

  const renderPermissions = () => (
    <div className="flex flex-col h-full animate-fade-in bg-white dark:bg-gray-900 transition-colors duration-300">
        {/* Header */}
        <div className="px-4 py-3 shadow-sm flex items-center gap-3 sticky top-0 z-10 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
          <button onClick={() => setView('profile')} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-600 dark:text-gray-300">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">App Permissions</h1>
        </div>
  
        <div className="p-6 overflow-y-auto">
          <div className="bg-blue-50 dark:bg-blue-900/30 border border-blue-100 dark:border-blue-900/50 rounded-xl p-4 mb-6">
             <div className="flex gap-3">
               <div className="bg-blue-100 dark:bg-blue-800 p-2 rounded-full h-fit shrink-0">
                  <Shield className="w-5 h-5 text-blue-600 dark:text-blue-300" />
               </div>
               <div>
                 <h3 className="font-bold text-blue-900 dark:text-blue-100 mb-1">Permission Usage</h3>
                 <p className="text-sm text-blue-800 dark:text-blue-200 leading-relaxed">
                   Camera, Microphone, and Gallery permissions will be requested when making video calls, making audio calls, and connecting the gallery to the app so that you can easily send photos from the gallery.
                 </p>
               </div>
             </div>
          </div>
  
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Manage Access</h3>
          
          <div className="space-y-4">
               {/* Camera */}
               <div className="flex items-center justify-between p-4 border border-gray-100 dark:border-gray-700 rounded-xl shadow-sm bg-white dark:bg-gray-800">
                  <div className="flex items-center gap-4">
                      <div className={`p-2.5 rounded-full ${appPermissions.camera ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400' : 'bg-gray-100 dark:bg-gray-700 text-gray-400'}`}>
                          <Camera className="w-5 h-5" />
                      </div>
                      <div>
                          <h4 className="font-semibold text-gray-800 dark:text-gray-100">Camera</h4>
                          <p className="text-xs text-gray-500 dark:text-gray-400">For Video Calls</p>
                      </div>
                  </div>
                  <div 
                    onClick={() => setAppPermissions(prev => ({...prev, camera: !prev.camera}))}
                    className={`relative inline-block w-11 h-6 transition duration-200 ease-in-out rounded-full cursor-pointer ${appPermissions.camera ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                  >
                      <span className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform shadow-sm ${appPermissions.camera ? 'translate-x-5' : 'translate-x-0'}`}></span>
                  </div>
               </div>
  
               {/* Microphone */}
               <div className="flex items-center justify-between p-4 border border-gray-100 dark:border-gray-700 rounded-xl shadow-sm bg-white dark:bg-gray-800">
                  <div className="flex items-center gap-4">
                      <div className={`p-2.5 rounded-full ${appPermissions.microphone ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400' : 'bg-gray-100 dark:bg-gray-700 text-gray-400'}`}>
                          <Mic className="w-5 h-5" />
                      </div>
                      <div>
                          <h4 className="font-semibold text-gray-800 dark:text-gray-100">Microphone</h4>
                          <p className="text-xs text-gray-500 dark:text-gray-400">For Audio & Video Calls</p>
                      </div>
                  </div>
                   <div 
                    onClick={() => setAppPermissions(prev => ({...prev, microphone: !prev.microphone}))}
                    className={`relative inline-block w-11 h-6 transition duration-200 ease-in-out rounded-full cursor-pointer ${appPermissions.microphone ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                  >
                      <span className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform shadow-sm ${appPermissions.microphone ? 'translate-x-5' : 'translate-x-0'}`}></span>
                  </div>
               </div>
  
               {/* Gallery */}
               <div className="flex items-center justify-between p-4 border border-gray-100 dark:border-gray-700 rounded-xl shadow-sm bg-white dark:bg-gray-800">
                  <div className="flex items-center gap-4">
                      <div className={`p-2.5 rounded-full ${appPermissions.gallery ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400' : 'bg-gray-100 dark:bg-gray-700 text-gray-400'}`}>
                          <ImageIcon className="w-5 h-5" />
                      </div>
                      <div>
                          <h4 className="font-semibold text-gray-800 dark:text-gray-100">Gallery</h4>
                          <p className="text-xs text-gray-500 dark:text-gray-400">To Send Photos</p>
                      </div>
                  </div>
                   <div 
                    onClick={() => setAppPermissions(prev => ({...prev, gallery: !prev.gallery}))}
                    className={`relative inline-block w-11 h-6 transition duration-200 ease-in-out rounded-full cursor-pointer ${appPermissions.gallery ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                  >
                      <span className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform shadow-sm ${appPermissions.gallery ? 'translate-x-5' : 'translate-x-0'}`}></span>
                  </div>
               </div>
          </div>
        </div>
    </div>
  );

  const renderAdSettings = () => (
    <div className="flex flex-col h-full animate-fade-in bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <div className="bg-white dark:bg-gray-800 px-4 py-3 shadow-sm flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => setView('profile')} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-600 dark:text-gray-300">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold text-gray-800 dark:text-white">Ad Settings</h1>
      </div>
      <div className="p-4 space-y-6">
         <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
             <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center gap-3">
                     <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded-full text-green-600 dark:text-green-400">
                         <Megaphone className="w-5 h-5" />
                     </div>
                     <div>
                         <h3 className="font-semibold text-gray-800 dark:text-gray-100">Show Ads</h3>
                         <p className="text-xs text-gray-500 dark:text-gray-400">Support development by enabling ads</p>
                     </div>
                 </div>
                 <div 
                    onClick={() => setShowAds(!showAds)}
                    className={`relative w-11 h-6 transition duration-200 ease-in-out rounded-full cursor-pointer ${showAds ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                  >
                      <span className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform shadow-sm ${showAds ? 'translate-x-5' : 'translate-x-0'}`}></span>
                  </div>
             </div>
             <p className="text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700/50 p-3 rounded-lg border border-gray-100 dark:border-gray-700 leading-relaxed">
                Advertisements help us keep the service free. They appear at the top and bottom of the screen. Disabling them is available for Premium users.
             </p>
         </div>
      </div>
    </div>
  );

  const renderBlockedContacts = () => (
    <div className="flex flex-col h-full animate-fade-in bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <div className="bg-white dark:bg-gray-800 px-4 py-3 shadow-sm flex items-center gap-3 sticky top-0 z-10 border-b border-gray-100 dark:border-gray-700">
        <button onClick={() => setView('privacy_settings')} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-600 dark:text-gray-300">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold text-gray-800 dark:text-white">Blocked Contacts</h1>
      </div>

      <div className="p-4 space-y-4 overflow-y-auto">
         {blockedUsers.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-gray-500 dark:text-gray-400">
                <UserX className="w-16 h-16 mb-4 text-gray-300 dark:text-gray-600" />
                <p>No blocked contacts</p>
            </div>
         ) : (
            blockedUsers.map(user => (
              <div key={user.id} className="flex items-center justify-between bg-white dark:bg-gray-800 p-3 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm">
                  <div className="flex items-center gap-3">
                      <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover grayscale opacity-70" />
                      <div>
                          <h3 className="font-semibold text-gray-700 dark:text-gray-200">{user.name}</h3>
                          <p className="text-xs text-gray-400">Blocked</p>
                      </div>
                  </div>
                  <button 
                    onClick={() => handleUnblock(user.id)}
                    className="px-4 py-1.5 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs font-bold rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 transition"
                  >
                      Unblock
                  </button>
              </div>
            ))
         )}
         
         <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl border border-blue-100 dark:border-blue-900/30 text-xs text-blue-800 dark:text-blue-300 leading-relaxed mt-6 flex gap-3">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>Blocked contacts will no longer be able to call you or send you messages. They will not be notified that you blocked them.</p>
         </div>
      </div>
    </div>
  );

  const renderCallHistory = () => (
    <div className="flex flex-col h-full animate-fade-in bg-white dark:bg-gray-900 transition-colors duration-300">
       <div className="px-4 py-4 bg-white dark:bg-gray-900 sticky top-0 z-10 shadow-sm flex justify-between items-center border-b dark:border-gray-800">
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Calls</h1>
          <button 
            onClick={simulateIncomingCall}
            className="flex items-center gap-2 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 px-3 py-1.5 rounded-full text-xs font-bold hover:bg-green-100 transition"
          >
             <PhoneIncoming className="w-4 h-4" /> Simulate Call
          </button>
       </div>
       <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {callHistory.map(log => {
             const user = contacts.find(c => c.id === log.userId) || { name: 'Unknown', avatar: 'https://via.placeholder.com/150', status: 'offline' } as User;
             return (
               <div key={log.id} className="flex items-center justify-between bg-white dark:bg-gray-800 p-3 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm">
                  <div className="flex items-center gap-3">
                      <img src={user.avatar} alt={user.name} className="w-12 h-12 rounded-full object-cover" />
                      <div>
                          <h3 className={`font-semibold ${user.name === 'Unknown' ? 'text-gray-500' : 'text-gray-900 dark:text-white'}`}>{user.name}</h3>
                          <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                             {log.direction === 'outgoing' ? <ArrowLeft className="w-3 h-3 rotate-45 text-green-500" /> : <ArrowLeft className="w-3 h-3 -rotate-135 text-red-500" />}
                             <span>{log.timestamp ? new Date(log.timestamp).toLocaleDateString() : 'Just now'}, {log.duration}</span>
                          </div>
                      </div>
                  </div>
                  <button onClick={() => startCall(user, log.type)} className="p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition">
                      {log.type === 'video' ? <Video className="w-5 h-5" /> : <Phone className="w-5 h-5" />}
                  </button>
               </div>
             );
          })}
       </div>
    </div>
  );

  const sentMediaType = (type: string) => {
    if (type === 'image') return '📷 Photo';
    if (type === 'audio') return '🎤 Voice Message';
    if (type === 'file') return '📄 File';
    return 'Message';
  };

  const renderChatList = () => {
    const filteredChats = chats.filter(c => {
        const other = c.participants.find(p => p.id !== currentUser?.id) || c.participants[0];
        const nameMatch = (c.groupName || other.name).toLowerCase().includes(chatSearchText.toLowerCase());
        // Simple filter implementation
        if (chatFilter === 'unread') return c.unreadCount > 0 && nameMatch;
        if (chatFilter === 'groups') return c.isGroup && nameMatch;
        return nameMatch;
    });

    return (
      <div className="flex flex-col h-full animate-fade-in bg-white dark:bg-gray-900 transition-colors duration-300">
        <div className="px-4 py-3 bg-white dark:bg-gray-900 sticky top-0 z-10 shadow-sm transition-colors duration-300">
           <div className="flex justify-between items-center mb-4">
              <h1 className="text-2xl font-bold text-blue-600 dark:text-blue-400">AS Chat</h1>
              <div className="flex gap-3">
                  <button onClick={() => setView('scan_code')} className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                      <Scan className="w-5 h-5" />
                  </button>
                  <button onClick={() => setView('add_friend')} className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                      <UserPlus className="w-5 h-5" />
                  </button>
                  <div className="relative">
                      <button onClick={() => setChatListMenuId(chatListMenuId ? null : 'main')} className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition">
                          <MoreVertical className="w-5 h-5" />
                      </button>
                      {chatListMenuId === 'main' && (
                          <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 py-2 z-50 animate-fade-in">
                              <button onClick={() => { setView('privacy_settings'); setChatListMenuId(null); }} className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm text-gray-700 dark:text-gray-200">Privacy Settings</button>
                              <button onClick={() => { setView('ad_settings'); setChatListMenuId(null); }} className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm text-gray-700 dark:text-gray-200">Ad Settings</button>
                              <button onClick={() => { handleLogout(); }} className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm text-red-600 dark:text-red-400">Logout</button>
                          </div>
                      )}
                  </div>
              </div>
           </div>
           
           {/* Search & Filter */}
           <div className="flex gap-2">
               <div className="flex-1 bg-gray-100 dark:bg-gray-800 rounded-xl flex items-center px-3 py-2.5 transition-colors duration-300">
                   <Search className="w-5 h-5 text-gray-400" />
                   <input 
                      type="text" 
                      placeholder="Search chats..." 
                      className="bg-transparent ml-2 outline-none text-sm w-full text-gray-800 dark:text-gray-200 placeholder-gray-500"
                      value={chatSearchText}
                      onChange={e => setChatSearchText(e.target.value)}
                   />
               </div>
           </div>
           
           {/* Chips */}
           <div className="flex gap-2 mt-3 overflow-x-auto pb-1 scrollbar-hide">
               {['All', 'Unread', 'Groups'].map(filter => (
                   <button 
                      key={filter}
                      onClick={() => setChatFilter(filter === 'All' ? '' : filter.toLowerCase())}
                      className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                          (chatFilter === filter.toLowerCase() || (filter === 'All' && !chatFilter))
                          ? 'bg-blue-600 text-white shadow-md' 
                          : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'
                      }`}
                   >
                       {filter}
                   </button>
               ))}
           </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {loading ? (
                <div className="flex justify-center pt-10">
                    <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
                </div>
            ) : filteredChats.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64 text-gray-400 dark:text-gray-500 text-center">
                    <MessageSquare className="w-16 h-16 mb-4 opacity-20" />
                    <p>No chats found.</p>
                    <button onClick={() => setView('contacts')} className="mt-4 text-blue-600 dark:text-blue-400 font-semibold text-sm">Start a new conversation</button>
                </div>
            ) : (
                filteredChats.map(chat => {
                    const otherUser = chat.participants.find(p => p.id !== currentUser?.id) || chat.participants[0];
                    const lastMsg = chat.messages[chat.messages.length - 1];
                    const isTyping = false; // Mock

                    return (
                        <div 
                            key={chat.id} 
                            onClick={() => { setActiveChatId(chat.id); setView('chat_room'); }}
                            className="flex items-center gap-3 p-3 rounded-2xl hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer transition active:scale-[0.99]"
                        >
                            <div className="relative">
                                <img src={chat.isGroup ? 'https://ui-avatars.com/api/?name=Group' : otherUser.avatar} className="w-14 h-14 rounded-full object-cover border border-gray-100 dark:border-gray-700" alt="Avatar" />
                                {!chat.isGroup && otherUser.status === 'online' && (
                                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-2 border-white dark:border-gray-900 rounded-full"></span>
                                )}
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-baseline mb-0.5">
                                    <h3 className="font-bold text-gray-900 dark:text-white truncate">{chat.isGroup ? chat.groupName : otherUser.name}</h3>
                                    {lastMsg && (
                                        <span className={`text-[10px] font-medium ${chat.unreadCount > 0 ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500'}`}>
                                            {new Date(lastMsg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                        </span>
                                    )}
                                </div>
                                <div className="flex justify-between items-center">
                                    <p className={`text-sm truncate pr-2 ${chat.unreadCount > 0 ? 'font-bold text-gray-800 dark:text-gray-200' : 'text-gray-500 dark:text-gray-400'}`}>
                                        {isTyping ? <span className="text-blue-500 italic">Typing...</span> : lastMsg ? (
                                            lastMsg.senderId === currentUser?.id ? `You: ${lastMsg.type === 'text' ? lastMsg.content : sentMediaType(lastMsg.type)}` : (lastMsg.type === 'text' ? lastMsg.content : sentMediaType(lastMsg.type))
                                        ) : 'Start chatting'}
                                    </p>
                                    {chat.unreadCount > 0 && (
                                        <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full min-w-[20px] text-center shadow-sm">
                                            {chat.unreadCount}
                                        </span>
                                    )}
                                    {chat.pinned && <Pin className="w-3 h-3 text-gray-400 ml-1 rotate-45" />}
                                </div>
                            </div>
                        </div>
                    );
                })
            )}
        </div>
        <button 
            onClick={() => setView('contacts')}
            className="absolute bottom-24 right-4 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 hover:scale-105 transition duration-200 z-20"
        >
            <Plus className="w-6 h-6" />
        </button>
      </div>
    );
  };

  const renderContacts = () => {
      const filtered = contacts.filter(c => c.name.toLowerCase().includes(contactSearchText.toLowerCase()));
      
      return (
        <div className="flex flex-col h-full animate-fade-in bg-white dark:bg-gray-900 transition-colors duration-300">
            <div className="px-4 py-4 sticky top-0 bg-white dark:bg-gray-900 z-10 border-b border-gray-100 dark:border-gray-800">
                <div className="flex justify-between items-center mb-4">
                   <h1 className="text-2xl font-bold text-gray-800 dark:text-white">People</h1>
                   <button onClick={() => setView('add_friend')} className="text-blue-600 dark:text-blue-400 text-sm font-bold flex items-center gap-1 bg-blue-50 dark:bg-blue-900/20 px-3 py-1.5 rounded-full">
                       <UserPlus className="w-4 h-4" /> Add Friend
                   </button>
                </div>
                <div className="bg-gray-100 dark:bg-gray-800 rounded-xl flex items-center px-3 py-2.5">
                   <Search className="w-5 h-5 text-gray-400" />
                   <input 
                      type="text" 
                      placeholder="Search contacts..." 
                      className="bg-transparent ml-2 outline-none text-sm w-full text-gray-800 dark:text-gray-200"
                      value={contactSearchText}
                      onChange={e => setContactSearchText(e.target.value)}
                   />
               </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {/* Invite option */}
                <div onClick={() => setView('invite_friends')} className="flex items-center gap-4 p-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 rounded-xl transition">
                    <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-300">
                        <Share2 className="w-6 h-6" />
                    </div>
                    <div>
                        <h3 className="font-bold text-gray-800 dark:text-gray-200">Invite Friends</h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Share app with others</p>
                    </div>
                </div>

                <h3 className="text-xs font-bold text-gray-400 uppercase mt-4 mb-2">My Contacts ({filtered.length})</h3>
                
                {filtered.map(contact => (
                    <div key={contact.id} onClick={() => handleStartChat(contact)} className="flex items-center gap-3 p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer transition">
                        <div className="relative">
                            <img src={contact.avatar} className="w-12 h-12 rounded-full object-cover" alt={contact.name} />
                            {contact.status === 'online' && <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-gray-800 rounded-full"></span>}
                        </div>
                        <div className="flex-1 border-b border-gray-50 dark:border-gray-800 pb-2">
                            <h3 className="font-semibold text-gray-800 dark:text-white">{contact.name}</h3>
                            <p className="text-xs text-gray-500 dark:text-gray-400 truncate w-48">{contact.bio || 'Available'}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      );
  };

  const renderProfile = () => {
    if (!currentUser) return null;
    return (
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900 animate-fade-in overflow-y-auto pb-20 transition-colors duration-300">
         {/* Cover Photo */}
         <div className="h-48 relative bg-gray-300 dark:bg-gray-800">
             <img src={currentUser.coverPhoto || 'https://picsum.photos/800/350'} className="w-full h-full object-cover" alt="Cover" />
             <button onClick={() => coverInputRef.current?.click()} className="absolute bottom-2 right-2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition backdrop-blur-sm">
                 <Camera className="w-4 h-4" />
             </button>
             <input type="file" ref={coverInputRef} className="hidden" accept="image/*" onChange={handleCoverPhotoUpdate} />
         </div>

         {/* Profile Info */}
         <div className="px-5 -mt-12 relative z-10 mb-6">
             <div className="flex justify-between items-end">
                 <div className="relative">
                     <div className="w-24 h-24 rounded-full border-4 border-white dark:border-gray-900 overflow-hidden shadow-lg bg-white dark:bg-gray-800">
                         <img src={currentUser.avatar} className="w-full h-full object-cover" alt="Avatar" />
                     </div>
                     <button onClick={() => profileInputRef.current?.click()} className="absolute bottom-0 right-0 bg-blue-600 text-white p-1.5 rounded-full border-2 border-white dark:border-gray-900 hover:bg-blue-700 transition shadow-sm">
                         <Camera className="w-3 h-3" />
                     </button>
                     <input type="file" ref={profileInputRef} className="hidden" accept="image/*" onChange={handleProfilePhotoUpdate} />
                 </div>
                 <button onClick={handleOpenQrModal} className="mb-2 text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 p-2 rounded-full hover:bg-blue-100 dark:hover:bg-blue-900/50 transition">
                     <QrCode className="w-6 h-6" />
                 </button>
             </div>
             
             <div className="mt-3">
                 <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{currentUser.name}</h2>
                 {/* Email Display Removed */}
             </div>

             {/* Bio */}
             <div className="mt-4 bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                 <div className="flex justify-between items-start mb-1">
                     <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Bio</h3>
                     {!isEditingBio && (
                         <button onClick={() => { setBioInput(currentUser.bio || ''); setIsEditingBio(true); }} className="text-blue-600 dark:text-blue-400 hover:text-blue-700">
                             <Edit2 className="w-4 h-4" />
                         </button>
                     )}
                 </div>
                 {isEditingBio ? (
                     <div>
                         <textarea 
                            className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-2 text-sm text-gray-800 dark:text-gray-200 outline-none focus:ring-2 focus:ring-blue-500"
                            rows={3}
                            value={bioInput}
                            onChange={e => setBioInput(e.target.value)}
                            maxLength={150}
                         />
                         <div className="flex justify-end gap-2 mt-2">
                             <button onClick={() => setIsEditingBio(false)} className="text-xs px-3 py-1.5 text-gray-500 dark:text-gray-400 font-medium">Cancel</button>
                             <button onClick={handleSaveBio} className="text-xs px-4 py-1.5 bg-blue-600 text-white rounded-lg font-bold shadow-sm">Save</button>
                         </div>
                     </div>
                 ) : (
                     <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">{currentUser.bio || 'No bio yet.'}</p>
                 )}
             </div>
         </div>

         {/* Settings Menu */}
         <div className="px-4 space-y-3">
             <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                 
                 {/* Dark Mode Toggle Removed */}

                 <button onClick={() => setView('privacy_settings')} className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition border-b border-gray-50 dark:border-gray-700">
                     <div className="bg-blue-50 dark:bg-blue-900/30 p-2 rounded-full text-blue-600 dark:text-blue-400"><Lock className="w-5 h-5" /></div>
                     <span className="font-medium text-gray-700 dark:text-gray-200 flex-1 text-left">Privacy & Security</span>
                     <ArrowLeft className="w-4 h-4 rotate-180 text-gray-400" />
                 </button>
                 
                 <button onClick={() => setView('ad_settings')} className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition border-b border-gray-50 dark:border-gray-700">
                     <div className="bg-orange-50 dark:bg-orange-900/30 p-2 rounded-full text-orange-600 dark:text-orange-400"><Megaphone className="w-5 h-5" /></div>
                     <span className="font-medium text-gray-700 dark:text-gray-200 flex-1 text-left">Ad Preferences</span>
                     <ArrowLeft className="w-4 h-4 rotate-180 text-gray-400" />
                 </button>

                 <button onClick={() => setView('permissions')} className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition border-b border-gray-50 dark:border-gray-700">
                     <div className="bg-green-50 dark:bg-green-900/30 p-2 rounded-full text-green-600 dark:text-green-400"><Shield className="w-5 h-5" /></div>
                     <span className="font-medium text-gray-700 dark:text-gray-200 flex-1 text-left">Permissions</span>
                     <ArrowLeft className="w-4 h-4 rotate-180 text-gray-400" />
                 </button>
                 
                 <button onClick={() => setView('blocked_contacts')} className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                     <div className="bg-red-50 dark:bg-red-900/30 p-2 rounded-full text-red-600 dark:text-red-400"><UserX className="w-5 h-5" /></div>
                     <span className="font-medium text-gray-700 dark:text-gray-200 flex-1 text-left">Blocked Contacts</span>
                     <ArrowLeft className="w-4 h-4 rotate-180 text-gray-400" />
                 </button>
             </div>

             <button onClick={handleLogout} className="w-full bg-white dark:bg-gray-800 rounded-2xl p-4 text-red-600 dark:text-red-400 font-bold shadow-sm border border-gray-100 dark:border-gray-700 flex items-center justify-center gap-2 hover:bg-red-50 dark:hover:bg-red-900/20 transition">
                 <LogOut className="w-5 h-5" /> Log Out
             </button>
             
             <p className="text-center text-xs text-gray-400 py-4">AS Chat v1.0.0 • Secure Build</p>
         </div>
      </div>
    );
  };

  const renderScanCode = () => (
    <div className="flex flex-col h-full bg-black relative animate-fade-in">
        <div className="absolute top-0 w-full p-4 flex justify-between items-center z-20">
            <button onClick={() => setView('chats')} className="p-2 bg-black/40 rounded-full text-white backdrop-blur-md">
                <ArrowLeft className="w-6 h-6" />
            </button>
            <div className="text-white font-bold text-lg drop-shadow-md">Scan QR Code</div>
            <button onClick={() => setFlashlightOn(!flashlightOn)} className={`p-2 rounded-full backdrop-blur-md transition ${flashlightOn ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.8)]' : 'bg-black/40 text-white'}`}>
                {flashlightOn ? <Zap className="w-6 h-6 fill-current" /> : <ZapOff className="w-6 h-6" />}
            </button>
        </div>

        {/* Camera Viewfinder Simulation */}
        <div className="flex-1 relative overflow-hidden flex items-center justify-center">
             <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&q=80')] bg-cover bg-center opacity-40"></div>
             {flashlightOn && <div className="absolute inset-0 bg-white/20 pointer-events-none mix-blend-overlay"></div>}
             
             {/* Scanner Frame */}
             <div className="w-64 h-64 border-2 border-white/50 rounded-3xl relative z-10 flex flex-col justify-between p-1 shadow-[0_0_0_9999px_rgba(0,0,0,0.7)]">
                 <div className="flex justify-between">
                     <div className="w-8 h-8 border-t-4 border-l-4 border-blue-500 rounded-tl-xl"></div>
                     <div className="w-8 h-8 border-t-4 border-r-4 border-blue-500 rounded-tr-xl"></div>
                 </div>
                 
                 {/* Scanning Line Animation */}
                 <div className="h-0.5 bg-blue-500 shadow-[0_0_10px_#3b82f6] w-full animate-[scan_2s_ease-in-out_infinite] absolute top-0 left-0"></div>

                 <div className="flex justify-between">
                     <div className="w-8 h-8 border-b-4 border-l-4 border-blue-500 rounded-bl-xl"></div>
                     <div className="w-8 h-8 border-b-4 border-r-4 border-blue-500 rounded-br-xl"></div>
                 </div>
             </div>
             
             <p className="absolute bottom-32 text-white/80 text-sm font-medium px-8 text-center drop-shadow-sm">
                 Align the QR code within the frame to scan
             </p>
        </div>

        {/* Result Popup */}
        {scanResult && (
            <div className="absolute bottom-0 w-full bg-white dark:bg-gray-800 rounded-t-3xl p-6 pb-12 shadow-[0_-5px_20px_rgba(0,0,0,0.5)] z-30 animate-slide-up">
                 <div className="flex items-center gap-4 mb-6">
                     <img src={scanResult.avatar} className="w-16 h-16 rounded-full object-cover border-2 border-blue-500 p-0.5" alt="Avatar" />
                     <div>
                         <h3 className="text-xl font-bold text-gray-800 dark:text-white">{scanResult.name}</h3>
                         <p className="text-sm text-gray-500 dark:text-gray-400">Found via QR Code</p>
                     </div>
                 </div>
                 <div className="flex gap-3">
                     <button onClick={() => { setView('chats'); }} className="flex-1 bg-gray-100 dark:bg-gray-700 py-3 rounded-xl font-bold text-gray-700 dark:text-gray-200">Cancel</button>
                     <button onClick={() => handleStartChat(scanResult)} className="flex-1 bg-blue-600 hover:bg-blue-700 py-3 rounded-xl font-bold text-white shadow-lg shadow-blue-500/30">Start Chat</button>
                 </div>
            </div>
        )}
    </div>
  );

  const renderInviteFriends = () => (
      <div className="flex flex-col h-full bg-blue-600 relative overflow-hidden animate-fade-in text-white">
          <button onClick={() => setView('contacts')} className="absolute top-4 left-4 p-2 bg-white/20 rounded-full hover:bg-white/30 transition z-20">
              <ArrowLeft className="w-6 h-6" />
          </button>
          
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center relative z-10">
               <div className="w-32 h-32 bg-white/10 rounded-full flex items-center justify-center mb-8 animate-bounce backdrop-blur-sm">
                   <Gift className="w-16 h-16 text-white" />
               </div>
               <h1 className="text-3xl font-bold mb-3">Invite Friends</h1>
               <p className="text-blue-100 mb-8 max-w-xs leading-relaxed">Share the fun! Invite your friends to AS Chat and connect instantly.</p>
               
               <div className="w-full max-w-xs bg-white/10 backdrop-blur-md rounded-2xl p-2 mb-8 border border-white/20 flex items-center justify-between">
                   <span className="text-sm font-mono px-4 opacity-80 truncate">as.app/u/{currentUser?.id}</span>
                   <button onClick={() => { navigator.clipboard.writeText(`https://as.app/u/${currentUser?.id}`); alert('Copied!'); }} className="bg-white text-blue-600 p-2 rounded-xl font-bold hover:bg-gray-100 transition">
                       <Copy className="w-4 h-4" />
                   </button>
               </div>
               
               <div className="flex gap-4">
                   <button onClick={handleShare} className="w-12 h-12 rounded-full bg-white text-blue-600 flex items-center justify-center shadow-lg hover:scale-110 transition"><Share2 className="w-6 h-6" /></button>
                   <button className="w-12 h-12 rounded-full bg-[#1877F2] text-white flex items-center justify-center shadow-lg hover:scale-110 transition"><Facebook className="w-6 h-6" /></button>
                   <button className="w-12 h-12 rounded-full bg-[#1DA1F2] text-white flex items-center justify-center shadow-lg hover:scale-110 transition"><Twitter className="w-5 h-5" /></button>
                   <button className="w-12 h-12 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-lg hover:scale-110 transition"><MessageCircle className="w-6 h-6" /></button>
               </div>
          </div>

          {/* Interactive Yarn Ball Animation */}
          <div 
             className={`absolute -bottom-20 left-1/2 transform -translate-x-1/2 w-48 h-48 bg-pink-500 rounded-full blur-sm opacity-20 transition-transform duration-500 cursor-pointer ${invitePulled ? 'scale-150' : 'scale-100'}`}
             onClick={handleYarnPull}
          ></div>
      </div>
  );

  const renderAddFriend = () => (
      <div className="flex flex-col h-full bg-white dark:bg-gray-900 animate-fade-in transition-colors duration-300">
          <div className="px-4 py-3 shadow-sm flex items-center gap-3 border-b border-gray-100 dark:border-gray-800">
             <button onClick={() => setView('contacts')} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-600 dark:text-gray-300">
                <ArrowLeft className="w-6 h-6" />
             </button>
             <h1 className="text-xl font-bold text-gray-800 dark:text-white">Add Friend</h1>
          </div>
          
          <div className="p-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Friend's Email Address</label>
              <div className="relative mb-6">
                  <Mail className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                  <input 
                      type="email" 
                      placeholder="name@gmail.com" 
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 dark:text-white transition"
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleSearchUser()}
                  />
                  <button 
                    onClick={handleSearchUser}
                    className="absolute right-2 top-2 bg-blue-600 text-white p-1.5 rounded-lg hover:bg-blue-700 transition"
                    disabled={isSearching}
                  >
                      {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  </button>
              </div>
              
              {addFriendSearchTriggered && (
                  <div className="animate-fade-in">
                      {foundUser ? (
                          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl p-4 shadow-sm text-center">
                              <img src={foundUser.avatar} className="w-20 h-20 rounded-full mx-auto mb-3 object-cover" alt="User" />
                              <h3 className="font-bold text-lg text-gray-900 dark:text-white">{foundUser.name}</h3>
                              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">{foundUser.email}</p>
                              
                              {contacts.some(c => c.id === foundUser.id) ? (
                                  <button className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 px-6 py-2 rounded-full font-bold text-sm cursor-default flex items-center gap-2 mx-auto">
                                      <CheckCircle2 className="w-4 h-4" /> Already Friends
                                  </button>
                              ) : (
                                  <button onClick={() => handleAddUser(foundUser)} className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-2.5 rounded-full font-bold shadow-lg shadow-blue-500/30 transition transform hover:scale-105">
                                      Add Friend
                                  </button>
                              )}
                          </div>
                      ) : (
                          <div className="text-center py-8">
                              <div className="bg-gray-100 dark:bg-gray-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                                  <UserX className="w-8 h-8 text-gray-400" />
                              </div>
                              <p className="text-gray-500 dark:text-gray-400 font-medium">{searchFeedback || 'User not found'}</p>
                          </div>
                      )}
                  </div>
              )}
          </div>
      </div>
  );

  const renderPrivacySettings = () => (
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900 animate-fade-in transition-colors duration-300">
          <div className="px-4 py-3 shadow-sm flex items-center gap-3 bg-white dark:bg-gray-800 sticky top-0 z-10 border-b border-gray-100 dark:border-gray-700">
             <button onClick={() => setView('profile')} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-600 dark:text-gray-300">
                <ArrowLeft className="w-6 h-6" />
             </button>
             <h1 className="text-xl font-bold text-gray-800 dark:text-white">Privacy</h1>
          </div>
          
          <div className="p-4 space-y-6 overflow-y-auto">
              {/* App Lock Section */}
              <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                      <div className="bg-purple-100 dark:bg-purple-900/30 p-2 rounded-full text-purple-600 dark:text-purple-400"><Unlock className="w-5 h-5" /></div>
                      <h3 className="font-bold text-gray-800 dark:text-white">App Lock</h3>
                  </div>
                  <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-600 dark:text-gray-300">Enable PIN Security</span>
                      <div 
                        onClick={toggleAppLockSetup}
                        className={`relative w-11 h-6 transition duration-200 ease-in-out rounded-full cursor-pointer ${securityPin ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                      >
                          <span className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform shadow-sm ${securityPin ? 'translate-x-5' : 'translate-x-0'}`}></span>
                      </div>
                  </div>
                  <p className="text-xs text-gray-400">Require a PIN to access the app.</p>
              </div>

              {/* Toggles */}
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden">
                   <div className="p-4 border-b border-gray-50 dark:border-gray-700 flex justify-between items-center">
                       <div>
                           <div className="flex items-center gap-2 mb-1">
                               <Eye className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                               <span className="font-semibold text-gray-800 dark:text-gray-200 text-sm">Last Seen</span>
                           </div>
                           <p className="text-xs text-gray-400">Who can see when you were last active</p>
                       </div>
                       <select 
                          className="bg-gray-50 dark:bg-gray-700 border-none text-xs rounded-lg p-2 font-medium text-gray-700 dark:text-gray-200 outline-none"
                          value={privacySettings.lastSeen}
                          onChange={e => setPrivacySettings({...privacySettings, lastSeen: e.target.value})}
                       >
                           <option>Everyone</option>
                           <option>My Contacts</option>
                           <option>Nobody</option>
                       </select>
                   </div>
                   
                   <div className="p-4 border-b border-gray-50 dark:border-gray-700 flex justify-between items-center">
                       <div>
                           <div className="flex items-center gap-2 mb-1">
                               <ImageIcon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                               <span className="font-semibold text-gray-800 dark:text-gray-200 text-sm">Profile Photo</span>
                           </div>
                           <p className="text-xs text-gray-400">Who can see your profile picture</p>
                       </div>
                       <select 
                          className="bg-gray-50 dark:bg-gray-700 border-none text-xs rounded-lg p-2 font-medium text-gray-700 dark:text-gray-200 outline-none"
                          value={privacySettings.profilePhoto}
                          onChange={e => setPrivacySettings({...privacySettings, profilePhoto: e.target.value})}
                       >
                           <option>Everyone</option>
                           <option>My Contacts</option>
                           <option>Nobody</option>
                       </select>
                   </div>
                   
                   <div className="p-4 flex justify-between items-center">
                       <div>
                           <div className="flex items-center gap-2 mb-1">
                               <CheckCircle2 className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                               <span className="font-semibold text-gray-800 dark:text-gray-200 text-sm">Read Receipts</span>
                           </div>
                           <p className="text-xs text-gray-400">Show when you've read messages</p>
                       </div>
                       <div 
                        onClick={() => setPrivacySettings({...privacySettings, readReceipts: !privacySettings.readReceipts})}
                        className={`relative w-11 h-6 transition duration-200 ease-in-out rounded-full cursor-pointer ${privacySettings.readReceipts ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'}`}
                      >
                          <span className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform shadow-sm ${privacySettings.readReceipts ? 'translate-x-5' : 'translate-x-0'}`}></span>
                      </div>
                   </div>
              </div>
              
              <button onClick={() => setView('blocked_contacts')} className="w-full bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                  <span className="font-semibold text-gray-800 dark:text-gray-200 text-sm">Blocked Contacts</span>
                  <div className="bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded text-xs text-gray-500 dark:text-gray-400 font-bold">{blockedUsers.length}</div>
              </button>
          </div>
      </div>
  );

  return (
    <div className="flex flex-col h-screen bg-white dark:bg-black max-w-md mx-auto shadow-2xl overflow-hidden relative font-sans transition-colors duration-300">
       <AdBanner position="top" visible={showAds} />

       <div className="flex-1 overflow-hidden relative bg-white dark:bg-black">
          {(isLocked || isSettingPin) && renderLockScreen()}
          
          {view === 'chats' && renderChatList()}
          {view === 'calls' && renderCallHistory()}
          {view === 'contacts' && renderContacts()}
          {view === 'profile' && renderProfile()}
          {view === 'chat_room' && activeChat && currentUser && (
             <ChatWindow 
               chat={activeChat} 
               currentUser={currentUser} 
               onBack={() => { setView('chats'); setActiveChatId(null); }}
               onStartCall={(type) => activeChat.participants.find(p => p.id !== currentUser.id) && startCall(activeChat.participants.find(p => p.id !== currentUser.id)!, type)}
               onBlockUser={handleBlockUser}
             />
          )}
          {view === 'permissions' && renderPermissions()}
          {view === 'ad_settings' && renderAdSettings()}
          {view === 'blocked_contacts' && renderBlockedContacts()}
          {view === 'scan_code' && renderScanCode()}
          {view === 'invite_friends' && renderInviteFriends()}
          {view === 'add_friend' && renderAddFriend()}
          {view === 'privacy_settings' && renderPrivacySettings()}
          
          {showQrModal && (
            <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowQrModal(false)}>
                <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-sm text-center shadow-2xl" onClick={e => e.stopPropagation()}>
                    <div className="flex justify-end">
                        <button onClick={() => setShowQrModal(false)}><X className="w-6 h-6 text-gray-400" /></button>
                    </div>

                    {isAiGeneratingQr ? (
                        <div className="py-12 flex flex-col items-center justify-center text-blue-600">
                            <Cpu className="w-16 h-16 animate-pulse mb-4" />
                            <div className="flex items-center gap-2 text-sm font-bold animate-pulse">
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span>AI Generating Unique Code...</span>
                            </div>
                        </div>
                    ) : (
                        <>
                            <div className="w-20 h-20 rounded-full border-4 border-white dark:border-gray-700 shadow-md overflow-hidden mx-auto -mt-10 mb-4 relative z-10">
                                <img src={currentUser?.avatar} className="w-full h-full object-cover" />
                            </div>
                            <h2 className="text-xl font-bold text-gray-800 dark:text-white">{currentUser?.name}</h2>
                            <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">Scan to chat with me on AS</p>
                            
                            <div className="bg-white p-2 rounded-xl border-2 border-dashed border-blue-200 inline-block mb-6 relative">
                                <QrCode className="w-48 h-48 text-gray-800" />
                                <div className="absolute -top-2 -right-2 bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-sm">
                                    AI Generated
                                </div>
                            </div>
                            
                            <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-xl flex items-center gap-2 text-xs text-gray-500 dark:text-gray-300 break-all border border-gray-100 dark:border-gray-600">
                                <span className="flex-1">https://as.app/u/{currentUser?.id}</span>
                                <button onClick={() => navigator.clipboard.writeText(`https://as.app/u/${currentUser?.id}`)} className="p-2 hover:bg-white dark:hover:bg-gray-600 rounded-lg shadow-sm">
                                    <Copy className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
          )}
       </div>

       {/* Bottom Navigation */}
       {(view === 'chats' || view === 'calls' || view === 'contacts' || view === 'profile') && renderBottomNav()}

       <AdBanner position="bottom" visible={showAds} />

       {activeCall && (
         <CallModal 
           user={activeCall.user} 
           type={activeCall.type} 
           direction={activeCall.direction}
           onEndCall={() => setActiveCall(null)} 
           onAnswer={() => {
               // Optional: Update call history or log answer here
           }}
         />
       )}
    </div>
  );
};

export default App;