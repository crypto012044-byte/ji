import React, { useState, useRef, useEffect } from 'react';
import { Chat, Message, User } from '../types';
import { ArrowLeft, Phone, Video, MoreVertical, Image as ImageIcon, Send, Shield, Download, Paperclip, Mic, Trash2, Play, Pause, X, FileText } from 'lucide-react';

interface ChatWindowProps {
  chat: Chat;
  currentUser: User;
  onBack: () => void;
  onStartCall: (type: 'audio' | 'video') => void;
  onBlockUser: (user: User) => void;
}

const PRESET_THEMES = [
  { id: 't1', url: 'https://images.unsplash.com/photo-1557683316-973673baf926?w=800&q=80', name: 'Blue Gradient' },
  { id: 't2', url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=800&q=80', name: 'Colorful' },
  { id: 't3', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=800&q=80', name: 'Dark Mode' },
  { id: 't4', url: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&q=80', name: 'Space' },
  { id: 't5', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80', name: 'Beach' },
  { id: 't6', url: 'https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?w=800&q=80', name: 'Nature' },
];

const ChatWindow: React.FC<ChatWindowProps> = ({ chat, currentUser, onBack, onStartCall, onBlockUser }) => {
  const [messages, setMessages] = useState<Message[]>(chat.messages);
  const [input, setInput] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [background, setBackground] = useState<string | undefined>(chat.theme);
  const [showThemePicker, setShowThemePicker] = useState(false);
  const [reactingToMessageId, setReactingToMessageId] = useState<string | null>(null);
  
  // Audio Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const recordingTimerRef = useRef<any>(null);
  
  // Audio Playback State
  const [playingMsgId, setPlayingMsgId] = useState<string | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);
  const longPressTimer = useRef<any>(null);

  // Participants logic (assuming 1-on-1 for simplicity if not group)
  const otherUser = chat.participants.find(p => p.id !== currentUser.id) || chat.participants[0];
  const title = chat.isGroup ? chat.groupName : otherUser.name;
  const subtitle = chat.isGroup 
    ? `${chat.participants.map(p => p.name.split(' ')[0]).join(', ')}` 
    : otherUser.status === 'online' ? 'Active now' : 'Last seen recently';

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isRecording]);

  // Recording Timer Logic
  useEffect(() => {
    if (isRecording) {
        recordingTimerRef.current = setInterval(() => {
            setRecordingSeconds(prev => prev + 1);
        }, 1000);
    } else {
        clearInterval(recordingTimerRef.current);
        setRecordingSeconds(0);
    }
    return () => clearInterval(recordingTimerRef.current);
  }, [isRecording]);

  const handleSend = () => {
    if (!input.trim()) return;
    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: currentUser.id,
      content: input,
      type: 'text',
      timestamp: Date.now(),
      read: false,
      reactions: []
    };
    setMessages([...messages, newMsg]);
    setInput('');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newMsg: Message = {
          id: Date.now().toString(),
          senderId: currentUser.id,
          content: 'Image',
          type: 'image',
          imageUrl: reader.result as string,
          timestamp: Date.now(),
          read: false,
          reactions: []
        };
        setMessages([...messages, newMsg]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          // Simulate document upload
          const fileSizeMB = (file.size / (1024 * 1024)).toFixed(1);
          const newMsg: Message = {
              id: Date.now().toString(),
              senderId: currentUser.id,
              content: 'File',
              type: 'file',
              fileName: file.name,
              fileSize: `${fileSizeMB} MB`,
              timestamp: Date.now(),
              read: false,
              reactions: []
          };
          setMessages([...messages, newMsg]);
      }
  };

  const handleChangeTheme = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            setBackground(reader.result as string);
            setShowThemePicker(false);
        };
        reader.readAsDataURL(file);
    }
  };

  // --- Voice Recording Functions ---
  const startRecording = () => {
      setIsRecording(true);
      if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(50);
  };

  const cancelRecording = () => {
      setIsRecording(false);
  };

  const sendAudioMessage = () => {
      const newMsg: Message = {
          id: Date.now().toString(),
          senderId: currentUser.id,
          content: 'Voice Message',
          type: 'audio',
          timestamp: Date.now(),
          read: false,
          duration: recordingSeconds,
          audioUrl: '#', // Mock URL
          reactions: []
      };
      setMessages([...messages, newMsg]);
      setIsRecording(false);
  };

  const formatDuration = (secs: number) => {
      const m = Math.floor(secs / 60);
      const s = secs % 60;
      return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const toggleAudioPlay = (id: string) => {
      if (playingMsgId === id) {
          setPlayingMsgId(null);
      } else {
          setPlayingMsgId(id);
      }
  };

  // --- Reaction Logic ---
  const startLongPress = (id: string) => {
    longPressTimer.current = setTimeout(() => {
      setReactingToMessageId(id);
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(50);
      }
    }, 500);
  };

  const endLongPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
  };

  const handleReaction = (emoji: string) => {
    if (!reactingToMessageId) return;

    setMessages(prev => prev.map(msg => {
      if (msg.id === reactingToMessageId) {
        const currentReactions = msg.reactions || [];
        const existingIndex = currentReactions.findIndex(r => r.emoji === emoji && r.userId === currentUser.id);
        
        let newReactions;
        if (existingIndex >= 0) {
          newReactions = currentReactions.filter((_, i) => i !== existingIndex);
        } else {
          newReactions = [...currentReactions, { emoji, userId: currentUser.id }];
        }
        return { ...msg, reactions: newReactions };
      }
      return msg;
    }));
    setReactingToMessageId(null);
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900 animate-fade-in relative transition-colors duration-300">
      {/* Top Bar */}
      <div className="bg-white dark:bg-gray-800 px-4 py-3 shadow-sm flex items-center justify-between z-10 transition-colors duration-300 border-b dark:border-gray-700">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-600 dark:text-gray-300">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-600 overflow-hidden">
            <img src={otherUser.avatar} alt="Avatar" className="w-full h-full object-cover" />
          </div>
          <div className="leading-tight">
            <h3 className="font-semibold text-gray-800 dark:text-gray-100">{title}</h3>
            <p className="text-xs text-green-600 dark:text-green-400 font-medium">{subtitle}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-blue-600 dark:text-blue-400">
          <button onClick={() => onStartCall('audio')} className="p-2 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-full transition">
            <Phone className="w-5 h-5" />
          </button>
          <button onClick={() => onStartCall('video')} className="p-2 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-full transition">
            <Video className="w-6 h-6" />
          </button>
          <div className="relative">
            <button onClick={() => setMenuOpen(!menuOpen)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-gray-600 dark:text-gray-300 transition">
                <MoreVertical className="w-5 h-5" />
            </button>
            
            {menuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 py-2 z-50">
                    <button 
                        className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm text-gray-800 dark:text-gray-200" 
                        onClick={() => { setMenuOpen(false); setShowThemePicker(true); }}
                    >
                        Change Theme
                    </button>
                    <button 
                        className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 text-sm text-red-600 dark:text-red-400"
                        onClick={() => {
                            onBlockUser(otherUser);
                            setMenuOpen(false);
                        }}
                    >
                        Block User
                    </button>
                </div>
            )}
             <input 
                type="file" 
                ref={bgInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={handleChangeTheme}
            />
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div 
        className="flex-1 overflow-y-auto p-4 space-y-4 relative"
        ref={scrollRef}
        style={{ 
            backgroundImage: background ? `url(${background})` : 'none',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
        }}
      >
        {background && <div className="absolute inset-0 bg-black/10 dark:bg-black/40 pointer-events-none fixed"></div>}

        <div className="flex justify-center my-4 relative z-0">
             <div className="bg-yellow-100 dark:bg-yellow-900/40 text-yellow-800 dark:text-yellow-200 text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-sm border border-yellow-200 dark:border-yellow-700">
                <Shield className="w-3 h-3" />
                Messages are end-to-end encrypted.
             </div>
        </div>

        {messages.map((msg) => {
          const isMe = msg.senderId === currentUser.id;
          
          const reactionCounts = (msg.reactions || []).reduce((acc: any, curr) => {
            acc[curr.emoji] = (acc[curr.emoji] || 0) + 1;
            return acc;
          }, {});

          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} relative z-0 mb-2`}>
              <div className="relative max-w-[85%] sm:max-w-[75%]">
                <div 
                    className={`rounded-2xl px-4 py-2 shadow-sm relative transition-transform active:scale-[0.98] ${
                        isMe 
                        ? 'bg-blue-600 text-white rounded-tr-none' 
                        : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100 rounded-tl-none border border-gray-100 dark:border-gray-700'
                    }`}
                    onMouseDown={() => startLongPress(msg.id)}
                    onMouseUp={endLongPress}
                    onMouseLeave={endLongPress}
                    onTouchStart={() => startLongPress(msg.id)}
                    onTouchEnd={endLongPress}
                    onTouchMove={endLongPress}
                    onContextMenu={(e) => e.preventDefault()}
                >
                    {msg.type === 'image' && msg.imageUrl ? (
                        <div className="mb-2 relative group">
                            <img src={msg.imageUrl} alt="Shared" className="rounded-lg max-h-60 object-cover" />
                            <a 
                                href={msg.imageUrl} 
                                download="image.png"
                                className="absolute bottom-2 right-2 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition"
                                onClick={(e) => e.stopPropagation()} 
                            >
                                <Download className="w-4 h-4" />
                            </a>
                        </div>
                    ) : msg.type === 'audio' ? (
                        <div className="flex items-center gap-3 min-w-[140px] py-1">
                            <button 
                                onClick={(e) => { e.stopPropagation(); toggleAudioPlay(msg.id); }}
                                className={`p-2 rounded-full flex items-center justify-center shrink-0 ${isMe ? 'bg-blue-500 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}
                            >
                                {playingMsgId === msg.id ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
                            </button>
                            <div className="flex flex-col flex-1">
                                <div className={`h-1 rounded-full w-full mb-1 ${isMe ? 'bg-blue-400' : 'bg-gray-200 dark:bg-gray-600'}`}>
                                    <div 
                                        className={`h-full rounded-full ${isMe ? 'bg-white' : 'bg-blue-500'}`} 
                                        style={{width: playingMsgId === msg.id ? '60%' : '0%'}} 
                                    ></div>
                                </div>
                                <span className={`text-[10px] ${isMe ? 'text-blue-100' : 'text-gray-400'}`}>
                                    {formatDuration(msg.duration || 0)}
                                </span>
                            </div>
                            <div className="relative flex items-end h-8 gap-0.5 opacity-50">
                                {[4,8,3,6,2,9,4,7].map((h, i) => (
                                    <div key={i} className={`w-1 rounded-full ${isMe ? 'bg-white' : 'bg-gray-800 dark:bg-gray-200'}`} style={{height: `${h*2}px`}}></div>
                                ))}
                            </div>
                        </div>
                    ) : msg.type === 'file' ? (
                        <div className="flex items-center gap-3 min-w-[150px] py-1">
                            <div className={`p-2 rounded-lg ${isMe ? 'bg-blue-500 text-white' : 'bg-orange-100 dark:bg-orange-900/30 text-orange-500'}`}>
                                <FileText className="w-6 h-6" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className={`text-sm font-semibold truncate max-w-[120px] ${isMe ? 'text-white' : 'text-gray-800 dark:text-gray-200'}`}>{msg.fileName}</p>
                                <p className={`text-[10px] ${isMe ? 'text-blue-100' : 'text-gray-500 dark:text-gray-400'}`}>{msg.fileSize} • Document</p>
                            </div>
                            <button className={`p-1 rounded-full ${isMe ? 'hover:bg-blue-500' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
                                <Download className={`w-4 h-4 ${isMe ? 'text-white' : 'text-gray-400'}`} />
                            </button>
                        </div>
                    ) : (
                        <p className="text-sm select-none">{msg.content}</p>
                    )}
                    <span className={`text-[10px] block text-right mt-1 ${isMe ? 'text-blue-200' : 'text-gray-400 dark:text-gray-500'}`}>
                        {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </span>
                </div>

                {Object.keys(reactionCounts).length > 0 && (
                   <div className={`absolute -bottom-3 ${isMe ? 'right-0' : 'left-0'} bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 shadow-sm rounded-full px-1.5 py-0.5 flex gap-1 items-center z-10 min-w-[20px] h-[20px] justify-center text-gray-800 dark:text-gray-100`}>
                      {Object.entries(reactionCounts).map(([emoji, count]) => (
                         <span key={emoji} className="text-[10px] leading-none flex items-center">
                           <span>{emoji}</span>
                           {Number(count) > 1 && <span className="text-gray-500 dark:text-gray-300 ml-0.5 text-[9px] font-bold">{Number(count)}</span>}
                         </span>
                      ))}
                   </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Input Area */}
      <div className="bg-white dark:bg-gray-800 px-4 py-3 border-t border-gray-200 dark:border-gray-700 flex items-center gap-2 z-10 transition-colors duration-300">
        {isRecording ? (
            <div className="flex-1 flex items-center gap-4 animate-fade-in">
                <button 
                    onClick={cancelRecording} 
                    className="p-3 rounded-full text-red-500 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/40 transition"
                >
                    <Trash2 className="w-5 h-5" />
                </button>
                <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full px-4 py-3 flex items-center gap-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-sm font-mono font-medium text-gray-700 dark:text-gray-200">{formatDuration(recordingSeconds)}</span>
                    <span className="text-xs text-gray-400">Recording audio...</span>
                </div>
                <button 
                    onClick={sendAudioMessage} 
                    className="p-3 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition shadow-md"
                >
                    <Send className="w-5 h-5" />
                </button>
            </div>
        ) : (
            <>
                <button onClick={() => fileInputRef.current?.click()} className="text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition p-2">
                    <ImageIcon className="w-6 h-6" />
                </button>
                <button onClick={() => docInputRef.current?.click()} className="text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition p-2">
                    <Paperclip className="w-5 h-5" />
                </button>
                
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleImageUpload}
                />
                
                <input 
                    type="file" 
                    ref={docInputRef} 
                    className="hidden" 
                    accept=".pdf,.doc,.docx,.txt" 
                    onChange={handleDocumentUpload}
                />

                <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full px-4 py-2 flex items-center">
                    <input 
                        type="text" 
                        placeholder="Type a message..." 
                        className="bg-transparent w-full outline-none text-sm text-gray-800 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    />
                </div>

                {input.trim() ? (
                    <button 
                        onClick={handleSend}
                        className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-full transition shadow-md"
                    >
                        <Send className="w-5 h-5" />
                    </button>
                ) : (
                    <button 
                        onClick={startRecording}
                        className="bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/40 text-blue-600 dark:text-blue-400 p-2.5 rounded-full transition"
                    >
                        <Mic className="w-5 h-5" />
                    </button>
                )}
            </>
        )}
      </div>

      {/* Reaction Picker Overlay */}
      {reactingToMessageId && (
         <div 
            className="fixed inset-0 z-50 bg-black/20 backdrop-blur-[2px] flex items-center justify-center animate-fade-in" 
            onClick={() => setReactingToMessageId(null)}
         >
            <div 
                className="bg-white dark:bg-gray-800 p-3 rounded-full shadow-2xl flex gap-3 animate-fade-in transform scale-100 border border-gray-100 dark:border-gray-700" 
                onClick={e => e.stopPropagation()}
            >
               {['👍', '❤️', '😂', '😮', '😢', '🙏'].map((emoji, index) => (
                  <button 
                    key={emoji} 
                    onClick={() => handleReaction(emoji)} 
                    className="w-10 h-10 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full text-2xl flex items-center justify-center transition hover:scale-125 active:scale-90"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    {emoji}
                  </button>
               ))}
            </div>
         </div>
      )}

      {/* Theme Picker Modal */}
      {showThemePicker && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center animate-fade-in" onClick={() => setShowThemePicker(false)}>
            <div className="bg-white dark:bg-gray-800 w-full sm:w-96 rounded-t-2xl sm:rounded-2xl p-4 max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-gray-800 dark:text-white">Choose Wallpaper</h3>
                    <button onClick={() => setShowThemePicker(false)} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"><X className="w-5 h-5 text-gray-500" /></button>
                </div>
                
                <div className="space-y-6">
                    {/* Custom & Default */}
                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            onClick={() => { bgInputRef.current?.click(); }}
                            className="flex flex-col items-center justify-center h-32 bg-gray-50 dark:bg-gray-700 rounded-xl border-2 border-dashed border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 transition hover:border-blue-300 group"
                        >
                            <div className="bg-white dark:bg-gray-600 p-2 rounded-full mb-2 shadow-sm group-hover:scale-110 transition">
                                <ImageIcon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                            </div>
                            <span className="text-xs font-bold text-gray-600 dark:text-gray-300">Upload from Gallery</span>
                        </button>
                        <button 
                            onClick={() => { setBackground(undefined); setShowThemePicker(false); }}
                            className="flex flex-col items-center justify-center h-32 bg-gray-100 dark:bg-gray-700 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600 transition relative overflow-hidden group border border-gray-200 dark:border-gray-600"
                        >
                            <span className="relative z-10 text-xs font-bold text-gray-600 dark:text-gray-300">Default</span>
                        </button>
                    </div>

                    {/* Presets */}
                    <div>
                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Presets</h4>
                        <div className="grid grid-cols-2 gap-3">
                            {PRESET_THEMES.map(theme => (
                                <button 
                                    key={theme.id}
                                    onClick={() => { setBackground(theme.url); setShowThemePicker(false); }}
                                    className="h-32 rounded-xl overflow-hidden relative group hover:shadow-lg transition transform hover:-translate-y-1"
                                >
                                    <img src={theme.url} className="w-full h-full object-cover transition duration-500 group-hover:scale-110" alt={theme.name} />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-3">
                                        <span className="text-white text-xs font-bold shadow-sm">{theme.name}</span>
                                    </div>
                                    {background === theme.url && (
                                        <div className="absolute top-2 right-2 bg-blue-600 w-2 h-2 rounded-full border border-white"></div>
                                    )}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default ChatWindow;