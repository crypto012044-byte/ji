import React from 'react';
import { X } from 'lucide-react';

// ==========================================
// ADMOB CONFIGURATION
// ==========================================
// These IDs are used when the app is wrapped for Android/iOS (e.g., via Capacitor/Cordova).
// For a pure web version, Google AdSense would be used instead.

// YOUR ADMOB APP ID
const ADMOB_APP_ID = "ca-app-pub-9086639227447709~8420354331";

// YOUR AD UNIT ID
const AD_UNIT_ID = "ca-app-pub-9086639227447709/3549147513";
// ==========================================

interface AdBannerProps {
  position: 'top' | 'bottom';
  visible?: boolean;
  onClose?: () => void;
}

const AdBanner: React.FC<AdBannerProps> = ({ position, visible = true, onClose }) => {
  if (!visible) return null;

  return (
    <div className={`w-full bg-gray-50 dark:bg-gray-800 border-${position === 'top' ? 'b' : 't'} border-gray-200 dark:border-gray-700 flex items-center justify-between px-4 py-3 z-40 relative shadow-sm transition-colors duration-300`}>
      {/* Hidden data attributes for Native Wrapper (e.g. Capacitor) to pick up if needed */}
      <div style={{display: 'none'}} data-admob-app-id={ADMOB_APP_ID} data-admob-unit-id={AD_UNIT_ID}></div>

      <div className="flex flex-col flex-1">
         <div className="flex items-center gap-2 mb-0.5">
            <span className="text-[10px] bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-300 px-1 rounded uppercase font-bold tracking-wider">Ad</span>
            <span className="text-[10px] text-gray-400">Sponsored</span>
         </div>
         <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-lg flex items-center justify-center text-white font-bold text-xs shadow-sm shrink-0">
               AS
            </div>
            <div className="min-w-0">
               <p className="text-sm font-semibold text-gray-800 dark:text-gray-100 leading-tight truncate">Premium Features</p>
               <p className="text-xs text-gray-500 dark:text-gray-400 truncate">Upgrade for an ad-free experience.</p>
            </div>
         </div>
      </div>
      <button className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-sm transition ml-2 shrink-0">
         Install
      </button>
      {onClose && (
        <button onClick={onClose} className="absolute top-1 right-1 p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
           <X className="w-3 h-3" />
        </button>
      )}
    </div>
  );
};

export default AdBanner;