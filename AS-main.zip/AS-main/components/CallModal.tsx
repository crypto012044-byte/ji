import React, { useEffect, useState } from 'react';
import { User } from '../types';
import { PhoneOff, Mic, MicOff, Video, VideoOff, Phone } from 'lucide-react';

interface CallModalProps {
  user: User;
  type: 'audio' | 'video';
  direction: 'incoming' | 'outgoing';
  onEndCall: () => void;
  onAnswer?: () => void;
}

const CallModal: React.FC<CallModalProps> = ({ user, type, direction, onEndCall, onAnswer }) => {
  // If outgoing, we assume connected/calling immediately. If incoming, we wait in 'ringing'.
  const [status, setStatus] = useState<'ringing' | 'connected'>(direction === 'incoming' ? 'ringing' : 'connected');
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(type === 'audio');

  useEffect(() => {
    let timer: any;
    if (status === 'connected') {
        timer = setInterval(() => setDuration(p => p + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [status]);

  const handleAnswer = () => {
      setStatus('connected');
      if (onAnswer) onAnswer();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between py-12 transition-colors duration-300 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md">
      {/* Background Effect - subtle avatar blur */}
      <div className="absolute inset-0 opacity-10 dark:opacity-20 bg-center bg-cover blur-3xl pointer-events-none" style={{ backgroundImage: `url(${user.avatar})` }}></div>
      
      {/* Header */}
      <div className="z-10 text-center animate-fade-in mt-10">
        <div className="w-32 h-32 rounded-full overflow-hidden mx-auto border-4 border-gray-100 dark:border-white/10 shadow-2xl mb-6 relative">
             <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{user.name}</h2>
        
        {status === 'ringing' ? (
            <p className="text-blue-600 dark:text-blue-300 text-lg animate-pulse font-medium">
                {direction === 'incoming' ? `Incoming ${type} call...` : 'Calling...'}
            </p>
        ) : (
            <p className="text-gray-600 dark:text-blue-200 text-lg font-mono">
                {formatTime(duration)}
            </p>
        )}
        
        <p className="text-xs text-gray-400 mt-4 flex items-center justify-center gap-1">
            <span className="w-2 h-2 bg-green-500 rounded-full"></span>
            End-to-End Encrypted
        </p>
      </div>

      {/* Video Streams (Only if connected and video type) */}
      {type === 'video' && status === 'connected' && (
        <div className="absolute inset-0 z-0 flex items-center justify-center pointer-events-none animate-fade-in">
             {/* Remote Stream (The other person) - Always visible in video call regardless of my camera state */}
             <img src="https://picsum.photos/800/1200" className="w-full h-full object-cover opacity-60 dark:opacity-40" alt="Remote Stream" />
             
             {/* Local Stream (Me) - Hidden or Placeholder if camera is off */}
             <div className="absolute bottom-32 right-4 w-28 h-40 bg-gray-900 rounded-xl border-2 border-white/20 overflow-hidden shadow-2xl flex items-center justify-center">
                {!cameraOff ? (
                    <img src="https://picsum.photos/200/300" className="w-full h-full object-cover" alt="Local Stream" />
                ) : (
                    <div className="flex flex-col items-center justify-center text-white/50">
                        <VideoOff className="w-6 h-6 mb-1" />
                        <span className="text-[10px]">Off</span>
                    </div>
                )}
             </div>
        </div>
      )}

      {/* Controls */}
      <div className="z-10 mb-8 w-full px-8">
        {status === 'ringing' && direction === 'incoming' ? (
            <div className="flex items-center justify-around w-full max-w-xs mx-auto animate-fade-in">
                 {/* Reject */}
                 <div className="flex flex-col items-center gap-3 group">
                    <button 
                        onClick={onEndCall}
                        className="w-16 h-16 rounded-full bg-red-500 text-white flex items-center justify-center shadow-lg hover:bg-red-600 transform group-hover:scale-110 transition duration-200"
                    >
                        <PhoneOff className="w-8 h-8" />
                    </button>
                    <span className="text-sm text-gray-600 dark:text-gray-300 font-medium">Decline</span>
                 </div>

                 {/* Accept */}
                 <div className="flex flex-col items-center gap-3 group">
                    <button 
                        onClick={handleAnswer}
                        className="w-16 h-16 rounded-full bg-green-500 text-white flex items-center justify-center shadow-lg hover:bg-green-600 transform group-hover:scale-110 transition duration-200 animate-bounce"
                    >
                        <Phone className="w-8 h-8 fill-current" />
                    </button>
                    <span className="text-sm text-gray-600 dark:text-gray-300 font-medium">Accept</span>
                 </div>
            </div>
        ) : (
            // Connected Controls
            <div className="flex items-center justify-center gap-6 bg-gray-100 dark:bg-gray-800/80 backdrop-blur-md px-8 py-4 rounded-3xl shadow-xl border border-gray-200 dark:border-gray-700 max-w-sm mx-auto">
                <button 
                    onClick={() => setIsMuted(!isMuted)}
                    className={`p-4 rounded-full transition ${isMuted ? 'bg-gray-900 text-white dark:bg-white dark:text-gray-900' : 'bg-white text-gray-700 hover:bg-gray-50 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600'}`}
                >
                {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </button>

                <button 
                    onClick={onEndCall}
                    className="p-5 rounded-2xl bg-red-500 text-white hover:bg-red-600 shadow-lg transform hover:scale-105 transition"
                >
                <PhoneOff className="w-8 h-8" />
                </button>

                {type === 'video' && (
                    <button 
                        onClick={() => setCameraOff(!cameraOff)}
                        className={`p-4 rounded-full transition ${cameraOff ? 'bg-gray-900 text-white dark:bg-white dark:text-gray-900' : 'bg-white text-gray-700 hover:bg-gray-50 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600'}`}
                    >
                    {cameraOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
                    </button>
                )}
            </div>
        )}
      </div>
    </div>
  );
};

export default CallModal;