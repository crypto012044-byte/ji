import React, { useState } from 'react';
import { User } from '../types';
import { mockService } from '../services/mockService';
import { MessageSquare, Lock, ArrowRight, ArrowLeft, Calendar, User as UserIcon, Mail, Key, CheckCircle2 } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  
  // Sign Up State Wizard
  // Step 1: Name, Step 2: DOB, Step 3: Email, Step 4: Password, Step 5: Success
  const [signupStep, setSignupStep] = useState(1);
  
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [dob, setDob] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const resetForm = () => {
    setSignupStep(1);
    setFirstName('');
    setLastName('');
    setDob('');
    setEmail('');
    setPassword('');
    setError(null);
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const user = await mockService.login(email, password);
      onLogin(user);
    } catch (err: any) {
      setError(err.message || 'Login failed');
      setLoading(false);
    }
  };

  const handleSignUpStep = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation logic per step
    if (signupStep === 1) {
        if (!firstName.trim() || !lastName.trim()) {
            setError("Please enter your full name.");
            return;
        }
        setSignupStep(2);
    } else if (signupStep === 2) {
        if (!dob) {
            setError("Please select your date of birth.");
            return;
        }
        setSignupStep(3);
    } else if (signupStep === 3) {
        if (!email.includes('@')) {
            setError("Please enter a valid Gmail address.");
            return;
        }
        
        setLoading(true);
        // Check if email exists
        const exists = await mockService.checkEmailExists(email);
        setLoading(false);

        if (exists) {
            setError("This Gmail is already registered. Please Sign In.");
            return;
        }

        // Email is valid and unique, move to Password
        setSignupStep(4);
    } else if (signupStep === 4) {
        if (password.length < 6) {
            setError("Password must be at least 6 characters.");
            return;
        }
        
        // Final Submission
        setLoading(true);
        try {
            const user = await mockService.signUp({
                firstName,
                lastName,
                dob,
                email,
                password
            });
            // Show Success Step briefly
            setSignupStep(5);
            setTimeout(() => {
                onLogin(user);
            }, 1500);
        } catch (err: any) {
            setError(err.message || "Registration failed.");
            setLoading(false);
        }
    }
  };

  // --- RENDER HELPERS ---

  const renderSignIn = () => (
    <form onSubmit={handleSignIn} className="space-y-4 animate-fade-in">
        <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Gmail / Email</label>
            <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <input
                type="email"
                required
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition bg-gray-50 dark:bg-gray-700 focus:bg-white dark:focus:bg-gray-800 dark:text-white"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@gmail.com"
                />
            </div>
        </div>
        <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Password</label>
            <div className="relative">
                <Key className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <input
                type="password"
                required
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition bg-gray-50 dark:bg-gray-700 focus:bg-white dark:focus:bg-gray-800 dark:text-white"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                />
            </div>
        </div>
        
        <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition duration-200 shadow-md flex justify-center items-center mt-4"
        >
            {loading ? (
            <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : (
            'Sign In'
            )}
        </button>
    </form>
  );

  const renderSignUp = () => (
      <form onSubmit={handleSignUpStep} className="space-y-5 animate-fade-in relative min-h-[280px] flex flex-col justify-between">
          {/* Progress Bar (Hidden on Success Step) */}
          {signupStep < 5 && (
            <div className="flex gap-1.5 mb-2">
                {[1, 2, 3, 4].map(s => (
                    <div key={s} className={`h-1 flex-1 rounded-full transition-all duration-300 ${s <= signupStep ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'}`}></div>
                ))}
            </div>
          )}

          <div className="flex-1 flex flex-col justify-center">
            {signupStep === 1 && (
                <div className="animate-fade-in">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">What's your name?</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">First Name</label>
                            <div className="relative mt-1">
                                <UserIcon className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                                <input
                                    type="text"
                                    autoFocus
                                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition bg-gray-50 dark:bg-gray-700 dark:text-white"
                                    value={firstName}
                                    onChange={e => setFirstName(e.target.value)}
                                    placeholder="ex. John"
                                />
                            </div>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">Last Name</label>
                            <div className="relative mt-1">
                                <UserIcon className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                                <input
                                    type="text"
                                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition bg-gray-50 dark:bg-gray-700 dark:text-white"
                                    value={lastName}
                                    onChange={e => setLastName(e.target.value)}
                                    placeholder="ex. Doe"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {signupStep === 2 && (
                <div className="animate-fade-in">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">When were you born?</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">Date of Birth</label>
                            <div className="relative mt-1">
                                <Calendar className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                                <input
                                    type="date"
                                    autoFocus
                                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition bg-gray-50 dark:bg-gray-700 text-gray-800 dark:text-white"
                                    value={dob}
                                    onChange={e => setDob(e.target.value)}
                                />
                            </div>
                            <p className="text-xs text-gray-400 mt-2">Your age will be visible on your profile unless you hide it.</p>
                        </div>
                    </div>
                </div>
            )}

            {signupStep === 3 && (
                <div className="animate-fade-in">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">Enter your Gmail</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">Email Address</label>
                            <div className="relative mt-1">
                                <Mail className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                                <input
                                    type="email"
                                    autoFocus
                                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition bg-gray-50 dark:bg-gray-700 dark:text-white"
                                    value={email}
                                    onChange={e => setEmail(e.target.value)}
                                    placeholder="you@gmail.com"
                                />
                            </div>
                            <p className="text-xs text-orange-500 mt-2 font-medium">Note: You cannot use this Gmail for another account once registered.</p>
                        </div>
                    </div>
                </div>
            )}

            {signupStep === 4 && (
                <div className="animate-fade-in">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">Create a Password</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">Password</label>
                            <div className="relative mt-1">
                                <Key className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                                <input
                                    type="password"
                                    autoFocus
                                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition bg-gray-50 dark:bg-gray-700 dark:text-white"
                                    value={password}
                                    onChange={e => setPassword(e.target.value)}
                                    placeholder="••••••••"
                                />
                            </div>
                            <p className="text-xs text-gray-400 mt-2">Must be at least 6 characters long.</p>
                        </div>
                    </div>
                </div>
            )}

            {signupStep === 5 && (
                <div className="animate-fade-in flex flex-col items-center justify-center py-8 text-center">
                    <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-6">
                        <CheckCircle2 className="w-10 h-10 text-green-600 dark:text-green-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Account Created!</h3>
                    <p className="text-gray-500 dark:text-gray-400">Logging you in...</p>
                </div>
            )}
          </div>

          <div className="flex gap-3 mt-6">
              {signupStep > 1 && signupStep < 5 && (
                  <button 
                    type="button" 
                    onClick={() => setSignupStep(prev => prev - 1)}
                    className="p-3 rounded-xl bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                  >
                      <ArrowLeft className="w-5 h-5" />
                  </button>
              )}
              {signupStep < 5 && (
                <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition duration-200 shadow-md flex justify-center items-center gap-2"
                >
                    {loading ? (
                        <div className="flex items-center gap-2">
                             <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                        </div>
                    ) : (
                    <>
                        {signupStep === 4 ? 'Create Account' : 'Next'}
                        {signupStep < 4 && <ArrowRight className="w-5 h-5" />}
                    </>
                    )}
                </button>
              )}
          </div>
      </form>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl p-8 w-full max-w-md animate-fade-in border border-white/20 dark:border-gray-700">
        <div className="flex justify-center mb-6">
          <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-2xl shadow-inner">
            <MessageSquare className="w-10 h-10 text-blue-600 dark:text-blue-400" />
          </div>
        </div>
        
        <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-1">
            {authMode === 'signin' ? 'Welcome Back' : 'Join AS Chat'}
            </h2>
            <p className="text-gray-500 dark:text-gray-400 text-sm">
            {authMode === 'signin' ? 'Enter your details to sign in.' : 'Connect with unique people online.'}
            </p>
        </div>

        {error && (
            <div className="mb-4 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 p-3 rounded-lg text-sm flex items-start gap-2 animate-fade-in border border-red-100 dark:border-red-900/50">
                <span className="font-bold">!</span> {error}
            </div>
        )}

        {authMode === 'signin' ? renderSignIn() : renderSignUp()}

        {signupStep < 5 && (
            <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-800 text-center">
            <button
                onClick={() => {
                    setAuthMode(authMode === 'signin' ? 'signup' : 'signin');
                    resetForm();
                }}
                className="text-sm font-semibold text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition"
            >
                {authMode === 'signin' ? (
                    <>New here? <span className="text-blue-600 dark:text-blue-400">Create an account</span></>
                ) : (
                    <>Already have an account? <span className="text-blue-600 dark:text-blue-400">Sign In</span></>
                )}
            </button>
            </div>
        )}

        <div className="mt-8 flex items-center justify-center text-[10px] text-gray-400 gap-1.5 uppercase tracking-wider font-semibold">
          <Lock className="w-3 h-3" />
          <span>Secure • Encrypted • Private</span>
        </div>
      </div>
    </div>
  );
};

export default Auth;